import AdminList from './AdminList'

export {
    AdminList
}