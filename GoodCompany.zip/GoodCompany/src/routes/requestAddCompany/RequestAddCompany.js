import React from 'react';
const RequestAddCompany = () => {
    return(
        <div>
        </div>
    )
}
export default RequestAddCompany;
